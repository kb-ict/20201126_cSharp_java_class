
public class ThirdProblem {

	public static void main(String[] args) {
	
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 9; j++) {
				System.out.printf("%dx%d=%d\n",(i+2),(j+1),((i+2)*(j+1)));
			}
		}

	}

}
