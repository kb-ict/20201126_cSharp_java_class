
public class SecondProblem {

	public static void main(String[] args) {

		short num1 = 3;
		short num2 = 5;
		System.out.printf("%d+%d=%d",num1,num2,num1+num2);
	}

}
