﻿using _210218_adressTest.util;
using System;
using System.Collections.Generic;
using System.Text;

namespace _210218_adressTest
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.menuSelector();
        }

        


    }
}
